package com.example.videoia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
 override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { VideoIA() } }
}

@Composable
fun VideoIA() {
 var idea by remember { mutableStateOf("") }
 var style by remember { mutableStateOf("Comique") }
 var duration by remember { mutableStateOf("30 s") }
 var loading by remember { mutableStateOf(false) }
 var progress by remember { mutableStateOf(0) }
 var result by remember { mutableStateOf(false) }

 LaunchedEffect(loading) {
   if (loading) {
     for (p in 0..100 step 10) { progress=p; delay(120) }
     loading=false; result=true
   }
 }

 MaterialTheme {
  Scaffold { pad ->
   Column(Modifier.fillMaxSize().padding(pad).padding(20.dp),
     verticalArrangement=Arrangement.spacedBy(16.dp)) {
    Text("🎬 VideoIA", style=MaterialTheme.typography.headlineLarge, fontWeight=FontWeight.Bold)
    Text("Crée une vidéo TikTok à partir d'une idée.")

    OutlinedTextField(
      value=idea, onValueChange={idea=it},
      modifier=Modifier.fillMaxWidth().height(140.dp),
      label={Text("Décris ta vidéo")},
      placeholder={Text("Ex : Un moustique se venge d'un homme...")}
    )

    Text("Style", fontWeight=FontWeight.Bold)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
      listOf("Comique","Anime","Réaliste").forEach {
        FilterChip(style==it,{style=it},{Text(it)})
      }
    }

    Text("Durée", fontWeight=FontWeight.Bold)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
      listOf("15 s","30 s","60 s").forEach {
        FilterChip(duration==it,{duration=it},{Text(it)})
      }
    }

    Button(
      onClick={loading=true; result=false},
      enabled=idea.isNotBlank() && !loading,
      modifier=Modifier.fillMaxWidth().height(56.dp)
    ) { Text(if(loading) "Création..." else "✨ CRÉER MA VIDÉO") }

    if(loading) {
      LinearProgressIndicator({progress/100f}, Modifier.fillMaxWidth())
      Text("Génération : $progress%")
    }

    if(result) {
      Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
          Text("Vidéo prête", fontWeight=FontWeight.Bold)
          Text("Le prototype est compilé correctement. Le moteur IA réel sera connecté au backend.")
          Button(onClick={result=false}) { Text("Créer une autre vidéo") }
        }
      }
    }
   }
  }
 }
}
